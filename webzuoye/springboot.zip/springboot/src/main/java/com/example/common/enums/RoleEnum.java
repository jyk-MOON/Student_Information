package com.example.common.enums;

public enum RoleEnum {
    // 用户
    USERT,
}
